# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import List, Literal, Optional, TypedDict, Union

from typing_extensions import NotRequired

from .auto_moderation import (
    AutoModerationAction,
    AutoModerationEventType,
    AutoModerationRule,
    AutoModerationTriggerMetadata,
    AutoModerationTriggerType,
)
from .channel import ChannelType, PermissionOverwrite, VideoQualityMode
from .guild import (
    DefaultMessageNotificationLevel,
    ExplicitContentFilterLevel,
    MFALevel,
    VerificationLevel,
)
from .integration import IntegrationExpireBehavior, PartialIntegration
from .role import Role
from .scheduled_events import ScheduledEventEntityType
from .snowflake import Snowflake
from .threads import Thread
from .user import User
from .webhook import Webhook

AuditLogEvent = Literal[
    1,
    10,
    11,
    12,
    13,
    14,
    15,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    30,
    31,
    32,
    40,
    41,
    42,
    50,
    51,
    52,
    60,
    61,
    62,
    72,
    73,
    74,
    75,
    80,
    81,
    82,
    83,
    84,
    85,
    90,
    91,
    92,
    100,
    101,
    102,
    110,
    111,
    112,
    140,
    141,
    142,
    143,
]


class _AuditLogChange_Str(TypedDict):
    key: Literal[
        "name",
        "description",
        "preferred_locale",
        "vanity_url_code",
        "topic",
        "code",
        "allow",
        "deny",
        "permissions",
        "tags",
    ]
    new_value: str
    old_value: str


class _AuditLogChange_AssetHash(TypedDict):
    key: Literal[
        "icon_hash", "splash_hash", "discovery_splash_hash", "banner_hash", "avatar_hash", "asset"
    ]
    new_value: str
    old_value: str


class _AuditLogChange_Snowflake(TypedDict):
    key: Literal[
        "id",
        "owner_id",
        "afk_channel_id",
        "rules_channel_id",
        "public_updates_channel_id",
        "widget_channel_id",
        "system_channel_id",
        "application_id",
        "channel_id",
        "inviter_id",
        "guild_id",
    ]
    new_value: Snowflake
    old_value: Snowflake


class _AuditLogChange_Bool(TypedDict):
    key: Literal[
        "widget_enabled",
        "nsfw",
        "hoist",
        "mentionable",
        "temporary",
        "deaf",
        "mute",
        "nick",
        "enabled_emoticons",
        "region",
        "rtc_region",
        "available",
        "archived",
        "locked",
        "enabled",
    ]
    new_value: bool
    old_value: bool


class _AuditLogChange_Int(TypedDict):
    key: Literal[
        "afk_timeout",
        "auto_archive_duration",
        "bitrate",
        "color",
        "default_auto_archive_duration",
        "max_age",
        "max_uses",
        "position",
        "prune_delete_days",
        "rate_limit_per_user",
        "user_limit",
    ]
    new_value: int
    old_value: int


class _AuditLogChange_ListRole(TypedDict):
    key: Literal["$add", "$remove"]
    new_value: List[Role]
    old_value: List[Role]


class _AuditLogChange_ListSnowflake(TypedDict):
    key: Literal["exempt_roles", "exempt_channels"]
    new_value: List[Snowflake]
    old_value: List[Snowflake]


class _AuditLogChange_MFALevel(TypedDict):
    key: Literal["mfa_level"]
    new_value: MFALevel
    old_value: MFALevel


class _AuditLogChange_VerificationLevel(TypedDict):
    key: Literal["verification_level"]
    new_value: VerificationLevel
    old_value: VerificationLevel


class _AuditLogChange_ExplicitContentFilter(TypedDict):
    key: Literal["explicit_content_filter"]
    new_value: ExplicitContentFilterLevel
    old_value: ExplicitContentFilterLevel


class _AuditLogChange_DefaultMessageNotificationLevel(TypedDict):
    key: Literal["default_message_notifications"]
    new_value: DefaultMessageNotificationLevel
    old_value: DefaultMessageNotificationLevel


class _AuditLogChange_ChannelType(TypedDict):
    key: Literal["type"]
    new_value: ChannelType
    old_value: ChannelType


class _AuditLogChange_IntegrationExpireBehaviour(TypedDict):
    key: Literal["expire_behavior"]
    new_value: IntegrationExpireBehavior
    old_value: IntegrationExpireBehavior


class _AuditLogChange_VideoQualityMode(TypedDict):
    key: Literal["video_quality_mode"]
    new_value: VideoQualityMode
    old_value: VideoQualityMode


class _AuditLogChange_Overwrites(TypedDict):
    key: Literal["permission_overwrites"]
    new_value: List[PermissionOverwrite]
    old_value: List[PermissionOverwrite]


class _AuditLogChange_ScheduledEventEntityType(TypedDict):
    key: Literal["entity_type"]
    new_value: ScheduledEventEntityType
    old_value: ScheduledEventEntityType


class _AuditLogChange_AutoModerationTriggerType(TypedDict):
    key: Literal["trigger_type"]
    new_value: AutoModerationTriggerType
    old_value: AutoModerationTriggerType


class _AuditLogChange_AutoModerationEventType(TypedDict):
    key: Literal["event_type"]
    new_value: AutoModerationEventType
    old_value: AutoModerationEventType


class _AuditLogChange_AutoModerationActions(TypedDict):
    key: Literal["actions"]
    new_value: List[AutoModerationAction]
    old_value: List[AutoModerationAction]


class _AuditLogChange_AutoModerationTriggerMetadata(TypedDict):
    key: Literal["trigger_metadata"]
    new_value: AutoModerationTriggerMetadata
    old_value: AutoModerationTriggerMetadata


AuditLogChange = Union[
    _AuditLogChange_AssetHash,
    _AuditLogChange_Bool,
    _AuditLogChange_ChannelType,
    _AuditLogChange_DefaultMessageNotificationLevel,
    _AuditLogChange_ScheduledEventEntityType,
    _AuditLogChange_ExplicitContentFilter,
    _AuditLogChange_Int,
    _AuditLogChange_IntegrationExpireBehaviour,
    _AuditLogChange_ListRole,
    _AuditLogChange_ListSnowflake,
    _AuditLogChange_MFALevel,
    _AuditLogChange_Overwrites,
    _AuditLogChange_Snowflake,
    _AuditLogChange_Str,
    _AuditLogChange_VerificationLevel,
    _AuditLogChange_VideoQualityMode,
    _AuditLogChange_AutoModerationTriggerType,
    _AuditLogChange_AutoModerationEventType,
    _AuditLogChange_AutoModerationActions,
    _AuditLogChange_AutoModerationTriggerMetadata,
]


class AuditEntryInfo(TypedDict):
    delete_member_days: str
    members_removed: str
    channel_id: Snowflake
    message_id: Snowflake
    count: str
    id: Snowflake
    type: Literal["0", "1"]
    role_name: str
    auto_moderation_rule_name: str
    auto_moderation_rule_trigger_type: str


class AuditLogEntry(TypedDict):
    target_id: Optional[str]
    user_id: Optional[Snowflake]
    id: Snowflake
    action_type: AuditLogEvent
    changes: NotRequired[List[AuditLogChange]]
    options: NotRequired[AuditEntryInfo]
    reason: NotRequired[str]


class AuditLog(TypedDict):
    webhooks: List[Webhook]
    users: List[User]
    audit_log_entries: List[AuditLogEntry]
    integrations: List[PartialIntegration]
    threads: List[Thread]
    auto_moderation_rules: List[AutoModerationRule]
